# ERP Financial Data Pipeline and Audit Analytics on Databricks

An end-to-end data engineering pipeline that ingests SAP-style ERP finance data, cleans and models it through **Bronze → Silver → Gold** layers using **PySpark and Delta Lake**, and validates it with automated data quality checks, then runs audit journal entry tests on the clean data. Built for the **audit data & analytics** use case: getting reliable ledger data ready for testing.

> Built on **Databricks Free Edition** with synthetic data. The Azure (ADF + ADLS) design is described below as a planned design, not a deployed one.

## Architecture

```
Source CSVs (SAP-style: BKPF, BSEG, LFA1, SKA1)
        |
        v
  BRONZE  - raw copy as Delta tables + ingestion timestamp and source file
        |
        v
  SILVER  - cleaned, typed, deduplicated; joined into journal_entries
        |
        v
  GOLD    - business aggregates (vendor, GL account, month, user)
        |
        v
  DATA QUALITY - reconciliation, nulls, referential integrity, debit = credit
```

## Data

Synthetic SAP-style finance tables (generated in notebook 01):

| Table | SAP name | Content | Rows |
|---|---|---|---|
| bkpf | BKPF | Accounting document headers | 20,000 |
| bseg | BSEG | Line items (S = debit, H = credit) | 40,050 |
| lfa1 | LFA1 | Vendor master | 150 |
| ska1 | SKA1 | GL account master | 7 |

Issues were deliberately injected so the pipeline has real work to do: duplicate rows, null vendors/users/cities, extra whitespace, and unbalanced documents.

## What each layer does

**Bronze** - loads the CSVs unchanged (all columns as text) into Delta tables and adds `_ingested_at` and `_source_file`, so the raw data can always be reprocessed.

**Silver** - trims whitespace, casts types (int, double, date), removes 50 duplicate line items, fills missing vendors from the other line of the same document, marks unknown users/cities, and joins the four tables into one `journal_entries` table with a signed amount, posting month and weekend flag.

**Gold** - four aggregate tables from the debit lines only (to avoid double counting): `vendor_summary`, `gl_summary`, `monthly_spend`, `user_activity`.

## Data quality checks

23 automated checks, results saved to `gold.dq_results`:

- Row-count reconciliation Bronze → Silver (after removing duplicate keys)
- Duplicate-key checks on every Silver table
- Null checks on critical columns
- Referential integrity (line items → headers, vendors, GL accounts)
- Debit = credit per document
- Silver → Gold total-spend reconciliation

**Result: 22 passed, 1 flagged.** The flagged check found **85 documents where debits ≠ credits** (saved to `gold.dq_unbalanced_documents`). This is a finding in the source data, not a pipeline failure. 25 were planted on purpose, and the other 60 arose from the round-amount and near-threshold edits made to the debit lines only.

## How to run

1. Sign up for Databricks Free Edition and import the notebooks from `/notebooks`.
2. Run in order: `00_setup` → `01_generate_source_data` → `02_bronze_ingestion` → `03_silver_transformation` → `04_gold_aggregates` → `05_data_quality_checks` → `06_audit_tests`.

## Planned Azure design (not deployed)

How the same flow would run on Azure:

- **Azure Data Lake Storage Gen2** containers `bronze`, `silver`, `gold` replace the Databricks schemas.
- **Azure Data Factory** ingests source files (Copy activity, parameterized ForEach over tables, scheduled trigger) and orchestrates the Databricks notebooks.
- **Azure SQL Database** receives the Gold tables for reporting.

## Challenges and learnings

- A Spark column-resolution error in the GL-account referential check (comparing columns from two separately created DataFrames) was fixed by renaming the key column and joining on the shared name.
- Summing both debit and credit lines would double count spend, so Gold reports use debit lines only.
- Reading everything as text in Bronze and typing in Silver keeps raw data intact for reprocessing.

## Audit analytics (notebook 06)

Six journal entry tests run in PySpark on the Silver `journal_entries` table. Exceptions are saved as `gold.audit_*` tables and a summary in `gold.audit_summary`.

| Test | Result | Why an auditor cares |
|---|---|---|
| Duplicate invoices (same vendor, amount, invoice date) | 0 groups | Possible double payment. None found because the synthetic data has no planted duplicates |
| Round amounts (multiples of 1,000, at least 10,000) | 30 lines | Possible estimates or fabricated entries |
| Weekend postings | 5,608 documents (28%) | Unusual timing. Dates are random in this synthetic data, so the rate is high; real data needs a holiday calendar |
| Just below the 50,000 approval limit | 106 lines vs 68 just above (ratio 1.56) | Possible splitting to avoid approval |
| Unbalanced documents | 85 documents | Debits do not equal credits. Matches the data quality check |
| Benford's Law on leading digits | Close conformity (MAD 0.0025) | Amounts follow the expected natural digit pattern |

Design choices: tests use debit lines or whole documents so nothing is double counted, and the threshold test compares the band below the limit with the same-size band above it, because a raw count alone is misleading.

## Next steps

- Orchestrate notebooks 02-06 with a Databricks Job (notebooks 02-05 already run as a job)
- Power BI dashboard on the Gold and audit tables

## Tech stack

Databricks, PySpark, Delta Lake, SQL, Python, Unity Catalog volumes, Benford's Law analysis
